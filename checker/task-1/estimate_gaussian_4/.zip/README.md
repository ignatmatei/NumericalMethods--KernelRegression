## Task 1 - Anomaly Detection

### Main challenges: 
    * optimal threshold - mi-a luat ceva sa inteleg ca trebuie sa iau nu doar toate probabilitatile ca si candidate pentru un epsilon optim, ci si practic orice valoare inermediara intre min si maxim, ca sa aflu precizia si recall ul pt fiecare.
    
### Learning moments:
    * procedeul de calculat outliersii pentru un anumit epsilon a fost interesant de citit (si dupa relativ usor de implementat :) )

## Task 2 - Kernel Regression 

### Main challenges:
    * sa intre cholesky in limita de timp pt get_prediction_params
   
### Learning moments:
    * cum se calculeaza estimarea produsa de un model a fost ceva ce nu stiam pana acum
    * implementarea MGC a fost relativ interesting
## Task 3 - Text Generation 

### Main challenges:
    * matricea stochastica (evident)
    * sa fac putin debug sa vad cum trebuie sa pun k_secv (separat cu spatiu si transpus)
### Learning moments:
    * conceptul de sliding window
